package com.company;

import java.io.*;
import java.net.*;

public class Server {

    private Game game;
    private int port;
    private int portForTest = 2001;
    private boolean running;

    public Server(Game game) {
        port = 2000;
        running = true;
        this.game = game;
    }

    public void serverToDetect() {
        if(game.getIPDetected()) {
            System.out.println("ТипаНашел");
            return;
        }
//        try {
//            InetAddress ipAddress1  = InetAddress.getByName("192.168.0.104");
//            Socket socket = new Socket(ipAddress1, port);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
        try {
            DatagramSocket ds = new DatagramSocket(9999);
            try {
                byte[] buffer = new byte[1024];
                DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
                ds.receive(packet);

                System.out.println(packet.getAddress().getHostAddress());                                               // + "  OPA \n " + new String(packet.getData(), 0, packet.getLength())

                InetAddress ipAddress = InetAddress.getByName(packet.getAddress().getHostAddress());
                System.out.println(game.getIPAdressOfOpponent() + "1Это айпи1");
                Socket socket = new Socket(ipAddress, portForTest);


                game.setIPDetected(true);
                game.setIPAdressOfOpponent(packet.getAddress().getHostAddress());

                System.out.println("end server");
            } catch (Exception e) { System.out.println("Nado");}
        } catch (Exception e) {
//            System.out.println("Already exists");
        }
    }

    public  void mainServer(){
        System.out.println("Started2");
        try {
            ServerSocket serverSocket = new ServerSocket(port);
            Socket socket = serverSocket.accept();
            System.out.println("Got a client ");

            InputStream sin = socket.getInputStream();
//            OutputStream sout = socket.getOutputStream();

            DataInputStream in = new DataInputStream(sin);
//            DataOutputStream out = new DataOutputStream(sout);

            String line = null;
            while (running){
                System.out.println("OPA");
                line = in.readUTF();
                System.out.println(line);
            }
        }catch (Exception e){e.printStackTrace();}
    }
}