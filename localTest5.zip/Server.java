package com.company;

import java.net.*;
import java.io.*;
import java.util.*;

public class Server {

    private Game game;
    private int port;
    private int portForTest = 2001;
    private boolean running;
    private boolean isItIp = true;
    public static boolean isTurnSeted = false;

    public Server(Game game) {
        port = 9000;
        running = true;
        this.game = game;
    }

    public void serverToDetect() {
        if (game.isIPDetected()) {
            return;
        }
        while (running) {
            try {
                DatagramSocket ds = new DatagramSocket(9999);
                try {
                    byte[] buffer = new byte[1024];
                    DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
                    ds.receive(packet);

//                    System.out.println(packet.getAddress().getHostAddress() + "Это айпи1");                                               // + "  OPA \n " + new String(packet.getData(), 0, packet.getLength())

                    if (!game.isIPDetected()) {
                        game.setIPDetected(true);
                        game.setIPAdressOfOpponent(packet.getAddress().getHostAddress());
                    } else {
                        if (!game.isSideIPdetected()) {
//                            System.out.println(packet.getAddress().getHostAddress());
                            if (game.getIPAdressOfOpponent().equals(packet.getAddress().getHostAddress()))
                                continue;
//                            System.out.println(packet.getAddress().getHostAddress() + " NAdo " + game.getIPAdressOfOpponent());
                            game.setSideIPdetected(true);
                            game.setSideIPAdress(packet.getAddress().getHostAddress());
                        } else {
                            running = false;
                            return;
                        }
                    }
                } catch (Exception e) {
                    ;
                }
            } catch (Exception e) {
            }
        }
    }

    public void mainServer() {
        try {

            ServerSocket serverSocket = new ServerSocket(port);
            Socket socket = serverSocket.accept();
            game.setLocalConnection(true);
            InputStream sin = socket.getInputStream();
            DataInputStream in = new DataInputStream(sin);
            String line = null;
            //ok
            while (running) {
                try {
                    line = in.readUTF();
//                    System.out.println(line + " " + game.isReady() + " ??");
                    if (isItIp) {
                        line.split(".");
                        if (!game.isSideIPdetected()) {
                            game.setSideIPAdress(line);
                            game.setSideIPdetected(true);
                        }
                        isItIp = false;

                        game.setLocalConnection(true);
                        game.setGameStarted(true);
                        game.repaint();

                    } else if (line.equals("Ready") && game.isReady() && !isTurnSeted) {

                        if (!isTurnSeted) {//&& Integer.parseInt(game.getSideIPAdress().split("\\.")[3]) > Integer.parseInt(game.getIPAdressOfOpponent().split("\\.")[3])) {
                            System.out.println("Ae");
                            game.setPlayersTurn(true);
                            isTurnSeted = true;
//                    } else if (!isTurnSeted) {
//                        System.out.println("Ne");
//                        game.setPlayersTurn(false);
//                        isTurnSeted = false;
//                    }
                        }
                        ListenerFactory.deleteMouseListener(ListenerFactory.MOUSE_LISTENER_FOR_BUTTONS, game);
                        ListenerFactory.deleteMouseListener(ListenerFactory.MOUSE_LISTENER_WHILE_PLACING, game);
                        game.getMv().addMouseListener(ListenerFactory.createMouseListener((ListenerFactory.MOUSE_LISTENER_WHILE_FIGHTNG), game));
                        game.setBattleCondition(true);
                        game.setJustReady(true);
                        game.setShootingJustStarted(true);
                        game.setReady(false);
//                    System.out.println("FIGHT");
                        //ok
                    } else if (isTurnSeted && line.split(" ").length == 2){
                        game.shooting(Integer.parseInt(line.split(" ")[0]), Integer.parseInt(line.split(" ")[1]));
                    }else if(isTurnSeted && game.isResultOfShotExpected()){
                        System.out.println("Kek");
                        game.setPlayersTurn(false);
                        String [][] opponentsField = game.getOpponentsField();
//                        int a
                        System.out.println("y  "+Integer.parseInt(game.getShotPlacement().getSecond().toString()) + " x  " + Integer.parseInt(game.getShotPlacement().getFirst().toString()) + "  "+line);
                        opponentsField[Integer.parseInt(game.getShotPlacement().getSecond().toString())][Integer.parseInt(game.getShotPlacement().getFirst().toString())] = line;
                        for(int i = 0;i<10;i++) {
                            for (int j = 0; j < 10; j++)
                                System.out.print(opponentsField[i][j] + " ");
                            System.out.println();
                        }
                        System.out.println();
                        game.setOpponentsField(opponentsField);
                        game.setShotPlacement(new Pair<>(0,0));
                        game.setResultOfShotExpected(false);
                        game.repaint();
                    }
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
        }catch (Exception e){e.printStackTrace();}
    }
}