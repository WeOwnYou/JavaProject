package com.company;

import java.io.*;
import java.net.*;

public class Server {
    public static void main(String []args) throws Exception {
        System.out.println("Start server");
        DatagramSocket ds = new DatagramSocket(9999);
        byte[] buffer = new byte[1024];
        DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
        ds.receive(packet);
        System.out.println(packet.getAddress().getHostAddress() + " " + new String(packet.getData(), 0, packet.getLength()));
        System.out.println("end server");
    }
}