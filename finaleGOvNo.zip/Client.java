package com.company;

import java.net.*;
import java.io.*;
import java.util.*;

public class Client {
    public static void main(String []args) throws Exception{
        System.out.println("Start client");
        String address = "10.1.0.108";


        MulticastSocket ms = new MulticastSocket(1024);
        String adr = InetAddress.getByName(address).getLocalHost().getHostAddress();
        System.out.println(adr);
        StringBuilder sb = new StringBuilder();
        Scanner scaner = new Scanner(adr);
        scaner.useDelimiter("\\.");
        sb.append(scaner.next()+".");
        sb.append(scaner.next()+".");
        sb.append(scaner.next()+".");
        sb.append(255);
        System.out.println(sb.toString());

        byte[] buffer = new byte[1024];
//        buffer = "OPA".getBytes();
        buffer = args[0].getBytes();
        System.out.println("Buffer Ready");

        InetAddress ipAddress = InetAddress.getByName(sb.toString());
//
//
        DatagramPacket packet = new DatagramPacket(buffer, buffer.length, ipAddress, 9999);
        ms.send(packet);
        System.out.println("Packet Sent");
        ServerSocket ss = new ServerSocket(4000);
        Socket client = ss.accept();
        System.out.println(client.getInetAddress().getHostAddress());
        System.out.println("end client");

//








































//        Socket socket1 = null;
////        InputStream sin1 = null;
////        OutputStream sout1 = null;
////        DataInputStream in1 = null;
////        DataOutputStream out1 = null;
////        InputStream sin2 = null;
////        OutputStream sout2 = null;
////        DataInputStream in2 = null;
////        DataOutputStream out2 = null;
////        BufferedReader keyboard = null;
////        int port = 1024;
////
////        String address = "10.1.0.108";//10.1.0.1 перебор
////        boolean running = true;
////        try {
////            InetAddress ipAddress = InetAddress.getByName(address);
////            System.out.println("Any of you heard of a socket with IP address " + address + " and port " + port + "?");
////            socket1 = new Socket(ipAddress, port);
////
////            sin1 = socket1.getInputStream();
////            sout1 = socket1.getOutputStream();
////
////            in1 = new DataInputStream(sin1);
////            out1 = new DataOutputStream(sout1);
////            System.out.println("Socket creat succ");
////        } catch (Exception e) {
////            System.out.println("Socket creat failed");
////        }
    }
}
