package com.company;

import java.net.*;

public class Server {
    private Game game;

    public Server(Game game) {
        this.game = game;
//            System.out.println("Start server");
    }

    public void serverToDetect() {
        try {
            DatagramSocket ds = new DatagramSocket(9999);
            try {
                byte[] buffer = new byte[1024];
                DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
                ds.receive(packet);
//                Game.ipAdressOfOpponent = packet.getAddress().getHostAddress();

                System.out.println(packet.getAddress().getHostAddress());                                               // + "  OPA \n " + new String(packet.getData(), 0, packet.getLength())

                this.game.setIPDetected(true);
                this.game.setIPAdressOfOpponent(packet.getAddress().getHostAddress());

                System.out.println("end server");
            } catch (Exception e) {
//                System.out.println("prikol");
            }
        } catch (Exception e) {
//            System.out.println("Already exists");
        }
    }
}