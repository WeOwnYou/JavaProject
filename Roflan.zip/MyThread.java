package com.company;

public class MyThread extends Thread {
    private String s;
    private Game game;
    private boolean IPdetected;

    public MyThread(String s, Game game, boolean IPdetected) {
        this.game = game;
        this.s = s;
        this.IPdetected = IPdetected;
    }

    public void run() {
            try {
//                System.out.println("Server must be started");
                Server server = new Server(game);
                server.serverToDetect();
                Client client = new Client(s, game);
                client.sendPacketToDetect();
            } catch (Exception e) {
                e.printStackTrace();
            }
    }
}
