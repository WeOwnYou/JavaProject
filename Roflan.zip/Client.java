package com.company;

import java.net.*;
import java.io.*;
import java.util.*;

public class Client extends Thread{                                                                                     //мб для других стей?
    private String s;
    private String address = "10.1.0.255";
    private boolean running = true;
    private Game game;
    public Client(String s, Game game) {
//        System.out.println("Started client");
        this.game = game;
        this.s = s;
        try {
            addressOfNetwork();
        } catch (Exception e) {System.out.println("Так не должно быть");}
    }

        public void addressOfNetwork() throws Exception{
            String adr = InetAddress.getByName(address).getLocalHost().getHostAddress();
            StringBuilder sb = new StringBuilder();
            Scanner scaner = new Scanner(adr);
            scaner.useDelimiter("\\.");
            sb.append(scaner.next()+".");
            sb.append(scaner.next()+".");
            sb.append(scaner.next()+".");
            sb.append(255);
            this.address = sb.toString();
        }

        public void sendPacketToDetect() throws Exception{

            MulticastSocket ms = new MulticastSocket(1024);


            byte[] buffer;
            buffer = s.getBytes();

            InetAddress ipAddress = InetAddress.getByName(address);
            DatagramPacket packet = new DatagramPacket(buffer, buffer.length, ipAddress, 9999);

            while(running) {
                try {
                    if(!game.getIPDetected())
                        running = false;
                    ms.send(packet);
                    System.out.println("Packet Sent");
                    Thread.sleep(10000);
                    ServerSocket ss = new ServerSocket(4000);
                    Socket client = ss.accept();
                    System.out.println(client.getInetAddress().getHostAddress());
                }catch(Exception e){;}
        }
    }
}
