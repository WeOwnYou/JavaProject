package com.company;

import javax.swing.*;
import java.awt.*;
import java.text.Format;
import java.util.ArrayList;

public class Shooting extends JPanel {

    private int gameField[][];
    private ArrayList<Ship> Ships;
    private MainWindow1 mv;
    private int numberOfShips[] = {0, 4 , 3, 2, 1};

    public Shooting(MainWindow1 mv, ArrayList<Ship> ships, int[][] gameField){ ,,,,убрать нахой
        this.mv = mv;
        this.Ships = ships;
        this.gameField = gameField;
    }

    public  int countCellSize() {                                                        //установка размеров клеток
        int cellSize;
        if (mv.getWidth() <= mv.getHeight()) {
            cellSize = (int)(mv.getWidth())/ 13;                        //сделать зависимость от процентов
            cellSize = (mv.getWidth() - 2 * cellSize) / 11;
        } else {
            cellSize = (int)(mv.getHeight()) / 13;
            cellSize = (mv.getHeight() - 2 * cellSize) / 11;
        }
        return cellSize;
    }

    public void shotComitted(int x, int y){
        if(gameField[y][x] == 1)
            partOfShipBlowed(x, y);
        else
            missed(x, y);

    }
    public void partOfShipBlowed(int x, int y){

    }
    public void missed(int x, int y){

    }
    public void paint(Graphics g){

    }

}
