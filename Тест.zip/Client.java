package com.company;

import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.MulticastSocket;
import java.util.Scanner;


public class Client {

    private int mainPort;
    private int portForDetect;
    private String addressOfNetwork;
//    private boolean IPDetected;

    public Client() {
//        IPDetected = false;
        mainPort = 9000;
        portForDetect = 3000;
        addressOfNetwork = "10.1.1.255";
        try {

            addressOfNetwork();
        }catch (Exception e){System.out.println("Хрень 0");}
    }

    public void addressOfNetwork() throws Exception {
        String adr = InetAddress.getByName(addressOfNetwork).getLocalHost().getHostAddress();
        StringBuilder sb = new StringBuilder();
        Scanner scaner = new Scanner(adr);
        scaner.useDelimiter("\\.");
        sb.append(scaner.next() + ".");
        sb.append(scaner.next() + ".");
        sb.append(scaner.next() + ".");
        sb.append(255);
        this.addressOfNetwork = sb.toString();
    }

    public void sendPacketToDetect() {
        System.out.println("Packets might be sended");
        if (Main.IPDetected)
            return;
        try {

            MulticastSocket ms = new MulticastSocket(2002);
            byte[] buffer;
            buffer = "1".getBytes();
            InetAddress ipAddress = InetAddress.getByName(addressOfNetwork);
            DatagramPacket packet = new DatagramPacket(buffer,buffer.length, ipAddress, 5000);
            while (true){
                try {
                    ms.send(packet);
                    if(Main.IPDetected)
                        return;
                    System.out.println("Packet send");
                }catch (Exception t){System.out.println("Packet not sending");}
            }

        } catch (Exception e) {
                System.out.println("Чрень");
        }
    }
}