package com.company;

public class MThread extends Thread {

    private Setver setver;
    private Client client;

    public MThread(){
        setver = new Setver();
        client = new Client();
    }

    public void run() {
        setver.serverForDetection();
        client.sendPacketToDetect();
    }
}
