package com.company;

import java.net.*;

public class Setver {

    private int portToDetect;
    private int mainPort;

    public Setver(){
        mainPort = 9000;
        portToDetect = 3000;
    }

    public void serverForDetection(){
        System.out.println("Server should recieve packets now");
        if(Main.IPDetected)
            System.out.println("НАйдено");
        try {
            DatagramSocket ds  = new DatagramSocket(9997);
            byte[] buffer = new byte[1024];
            DatagramPacket packet = new DatagramPacket(buffer,buffer.length);
            ds.receive(packet);
            System.out.println(packet.getAddress().getHostAddress() + " Это предполагаемый адресс ");

            InetAddress ipAddress = InetAddress.getByName(packet.getAddress().getHostAddress().toString());
            try {
                Socket socket = new Socket(ipAddress, 2000);
                return;
            }catch (ConnectException x){System.out.println("Не тот айпи");}
            Main.IPDetected = true;
            System.out.println("Ok");
        }catch (Exception e){System.out.println("XZ"); e.printStackTrace();}
    }

}
