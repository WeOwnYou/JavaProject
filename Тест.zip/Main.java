package com.company;

public class Main {
    public static boolean IPDetected = false;
    public static void main(String[] args) {
//        Setver setver = new Setver();
//        Client client = new Client();
//        setver.serverForDetection();
//        client.sendPacketToDetect();
        MThread t = new MThread();
//        t.start();
        t.run();
    }
}
