package com.company;

public class MainServer {
}
