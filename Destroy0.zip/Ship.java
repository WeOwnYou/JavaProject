package com.company;

import javax.imageio.ImageIO;
import java.awt.*;
import java.io.File;
import java.io.IOException;

import static java.lang.Math.abs;
import static java.lang.StrictMath.*;

public  class Ship {

    private int x0, x1, y0, y1, len, numberOfCells;
    private Image shipImg, blowImg, missImg, destroyedShipImage;                              //картинку найти
    private boolean isHorizontal, isDestroyed;

    public  Ship (int x0, int y0, int x1, int y1, boolean isHorizontal){               //isHorizontal
        this.isHorizontal = isHorizontal;
        this.x0 = x0;
        this.y0 = y0;
        this.x1 = x1;
        this.y1 = y1;
        isDestroyed = false;
        numberOfCells = max(abs(x0-x1), abs(y0-y1));
//        System.out.println(x0 + " "+ y0 + " " + x1+ " "+ y1);
        try {
            shipImg = ImageIO.read(getClass().getResource("/resources/ship.png"));
            destroyedShipImage = ImageIO.read(getClass().getResource("/resources/destroyedShip.png"));      //нормальный путь сделать
        } catch (IOException e) {
//            System.out.println("Images isnt loading");
        }
    }

    public Image getShipImg() {
        return shipImg;
    }


    public int getY0() {
        return y0;
    }

    public int getX0() {
        return x0;
    }

    public int getX1() {return x1;}

    public int getY1() {
        return y1;
    }

    public boolean getIsHorizontal() {return isHorizontal;}

    public Image getBlowImg() {return blowImg;}

    public Image getMissImg() {return missImg;}

    public boolean isDestroyed() {
        return isDestroyed;
    }

    public void setDestroyed(boolean destroyed) {
        isDestroyed = destroyed;
    }

    public int getNumberOfCells() {
        return numberOfCells;
    }

    public void setNumberOfCells(int numberOfCells) {
        this.numberOfCells = numberOfCells;
    }

    public Image getDestroyedShipImage() {
        return destroyedShipImage;
    }

    public void setDestroyedShipImage(Image destroyedShipImage) {
        this.destroyedShipImage = destroyedShipImage;
    }
}
