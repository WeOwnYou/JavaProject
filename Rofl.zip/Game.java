package com.company;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.geom.AffineTransform;
import java.awt.image.AffineTransformOp;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.*;
import java.util.ArrayList;
import java.nio.file.*;

public class Game extends JPanel {


    private String [][] gameField;
    private String [][] oppponentsGameField;
    private ArrayList<Ship> Ships;
    private MainWindow1 mv;
    private int numberOfShips[];
    private int cellSize;
    private boolean gameStarted = false;
    private double rotationOfLoaingMark;
    private int indent;

    private boolean isStartPressed = false;
    private boolean isReady = false;
    private boolean isJustReady = false;
    private boolean isStartOfGame = false;
    private boolean isShootingJustStarted = false;
    private boolean isPlayersTurn;
    private boolean isPropablePlayersTurn;
    private boolean isActionPerformed = false;



    private String IPAdressOfOpponent;
    private boolean IPdetected = false;
    private boolean sideIPdetected = false;
    private String sideIPAdress = null;

    private boolean battleCondition;
    private boolean localConnection = false;


    public int countCellSize() {                                                                                         //установка размеров клеток и поля в целом работает в отношении с полем
        int cellSize;
        if (mv.getWidth() <= mv.getHeight()) {
            cellSize = (int) (mv.getWidth() * 2.2) / 13;
            cellSize = (mv.getWidth() - 2 * cellSize) / 11;
        } else {
            cellSize = (int) (mv.getHeight() * 2.2) / 13;
            cellSize = (mv.getHeight() - 2 * cellSize) / 11;
        }
        cellSize = (int)(cellSize/1.5);
        return cellSize;
    }

//    public static void getRealtivePath(String relPath, String absPath){
//        Path pathAbsolute = Paths.get(absPath);
//        Path pathBase = Paths.get(relPath);
//        Path pathRelative = pathBase.relativize(pathAbsolute);
//        System.out.println(pathRelative);
//    }

    public Game(MainWindow1 mv) {
//        repaint();


        battleCondition = false;
        numberOfShips = new int[]{0, 4, 3, 2, 1};
        gameField = new String[10][10];
        IPdetected = false;
        Ships = new ArrayList<Ship>(10);
        this.mv = mv;

        mv.addMouseListener(ListenerFactory.createMouseListener((ListenerFactory.MOUSE_LISTENER_WHILE_PLACING), this));
        mv.addMouseListener(ListenerFactory.createMouseListener((ListenerFactory.MOUSE_LISTENER_FOR_BUTTONS), this));
        mv.addMouseListener(ListenerFactory.createMouseListener((ListenerFactory.MOUSE_LISTENER_FOR_START_WINDOW),this));

    }

    public void createShip(int x0, int y0, int x1, int y1, boolean isHorizontal) {                                      //запихивание информации о корабле в корбаль, а также в поле и колличество кораблей
        if(battleCondition)
            return;
        int len = Math.max(Math.abs(x1 - x0) + 1, Math.abs(y1 - y0) + 1);
        if (len > 4) {                                                                                                  //считает палубы до 4 (выводить на экран как ошибку)
            System.out.println("na ekran");
            return;
        }
        if (!(numberOfShips[len] > 0))                                                                                  //кораблей такого вида очень много
            return;

        if (isHorizontal) {                                                                                             //(может можно убрать) разная отрисовка горизонтальных и вертикальных кораблей
            int ix1 = Math.max(x0, x1), ix0 = Math.min(x0, x1);
            int iy1 = Math.max(y0, y1), iy0 = Math.min(y0, y1);
            for (int i = ix0; i <= ix1; i++)                                                                            //проверка на возможность поставить
                if (gameField[iy0][i] == "1" || gameField[iy0][i] == "2") {
                    return;
                }

            for (int i = ix0 - 1; i <= ix1 + 1; i++)                                                                    //запрет на постановку кораблей около данного
                for (int j = iy0 - 1; j <= iy1 + 1; j++) {
                    try {
                        if (ix0 <= i && i <= ix1 && iy0 <= j && iy1 >= j)
                            gameField[j][i] = "1";
                        else
                            gameField[j][i] = "2";
                    } catch (IndexOutOfBoundsException e) {
                        ;
                    }
                }
        } else {
            int ix1 = Math.max(x0, x1), ix0 = Math.min(x0, x1);
            int iy1 = Math.max(y0, y1), iy0 = Math.min(y0, y1);

            for (int i = iy0; i <= iy1; i++)
                if (gameField[i][ix0] == "1" || gameField[i][ix0] == "2") {
                    return;
                }
            for (int i = iy0 - 1; i <= iy1 + 1; i++)
                for (int j = ix0 - 1; j <= ix1 + 1; j++) {
                    try {
                        if (iy0 <= i && iy1 >= i && ix0 <= j && ix1 >= j)
                            gameField[i][j] = "1";
                        else
                            gameField[i][j] = "2";
                    } catch (IndexOutOfBoundsException e) {
                        ;
                    }
                }
        }

        numberOfShips[len] -= 1;                                                                                        //фактическое создание корабля и отрисовка
        Ship s = new Ship(x0, y0, x1, y1, isHorizontal);
        Ships.add(s);
        repaint();

//        for (int i = 0; i < 10; i++) {                                                                                  //игровое поле
//            for (int j = 0; j < 10; j++)
//                System.out.print(gameField[i][j] + " ");
//            System.out.println();
//        }
//        System.out.println();
//        System.out.println();
//        System.out.println();
    }

    public void shooting(int x, int y){
        if(!battleCondition)
            return;
        boolean tempfl = false;
        for(int i = 0; i < 10;i++) {
            for (int j = 0; j < 10; j++)
                if (gameField[y][x] == "1") {
                    gameField[y][x] = "-1";
                    System.out.println("HURT");
                    tempfl = true;
                    break;
                } else {
                    if(!(gameField[y][x] == "-1")) {
                        System.out.println("NOT HURT");
                        gameField[y][x] = "-2";
                    }
                    tempfl = true;
                    break;
                }
            if(tempfl)
                break;
        }
        System.out.println(x + " " +y);
//        for (int i = 0; i < 10; i++) {                                                                                  //игровое поле
//            for (int j = 0; j < 10; j++)
//                System.out.print(gameField[i][j] + " ");
//            System.out.println();
//        }
        System.out.println();
        System.out.println();
        System.out.println();
        repaint();
    }

    public int[] getCoordsOfButtonsForPlacingResetAndAccept() {
        int[] t = {0, 0, 0, 0, 0};
//        cellSize = countCellSize();
        int x1 = (int) (cellSize * 11 + cellSize * 1.66), y1 = (int) (cellSize * 11 + cellSize);
        int y2 = y1, x2 = (int) (cellSize * 11 + cellSize * 2.32);
        t[0] = x1;
        t[1] = y1;
        t[2] = x2;
        t[3] = y2;
        t[4] = (int) (cellSize * 0.5);
        return t;
    }


    public void paint(Graphics g){
        cellSize = countCellSize();
        super.paint(g);
        if(gameStarted)
            paintSelfField(g);
        else
            paintStartWindow(g);
    }

    public void paintSelfField(Graphics g) {                                                                            //общая отрисовка
        drawField(g);
        paintButtons(g);
        paintShips(g);
        if(isBattleCondition()) {                                                                                    //УБРАТЬ КОммеНТарИИ
            System.out.println("Delete");
            ListenerFactory.deleteMouseListener(ListenerFactory.MOUSE_LISTENER_FOR_BUTTONS, this);
            ListenerFactory.deleteMouseListener(ListenerFactory.MOUSE_LISTENER_WHILE_PLACING, this);
        }
        if(battleCondition)
            paintHoles(g);
    }

    public void drawField(Graphics g) {                                                                                 //отрисовка поля (пока линии, потом ещё кнопки с акшон листенерами)
        g.setColor(Color.BLACK);
        for (int i = 0; i < 2; i++)
            for (int j = 0; j <= 10; j++) {
                if (i == 0) {
                    g.drawLine(cellSize + j * cellSize, cellSize, cellSize + j * cellSize, cellSize * 11);
                } else
                    g.drawLine(cellSize, cellSize + j * cellSize, cellSize * 11, cellSize + j * cellSize);
            }
    }


    public void paintShips(Graphics g) {                                                                                   //отрисовка кораблей
        for (int i = 0; i < Ships.size(); i++) {
            int lenx = Ships.get(i).getX1() - Ships.get(i).getX0() + 1;
            int leny = Ships.get(i).getY1() - Ships.get(i).getY0() + 1;
            paintShip(g, Ships.get(i).getShipImg(), cellSize + Ships.get(i).getX0() * cellSize, cellSize + Ships.get(i).getY0() * cellSize,
                    lenx * cellSize, leny * cellSize, Ships.get(i).getIsHorizontal());
        }
//        System.out.println(IPAdressOfOpponent);
    }

    public void paintHoles(Graphics g) {
        Image hole = null;
        Image blow = null;
        try {
            hole = ImageIO.read(getClass().getResource("/resources/hole.png"));
            blow = ImageIO.read(getClass().getResource("/resources/blow.png"));

        } catch (Exception e) {
            e.printStackTrace();
        }

        for(int i = 0; i < 10; i++)
            for(int j = 0; j < 10; j++)
                if(gameField[i][j] == "-2")
                    g.drawImage(hole, j*cellSize + cellSize, i*cellSize + cellSize, cellSize, cellSize, null);
                else if(gameField[i][j] == "-1")
                    g.drawImage(blow, j*cellSize + cellSize, i*cellSize + cellSize, cellSize, cellSize, null);
    }

    public void paintShip(Graphics g, Image img, int x, int y, int width, int height, boolean isHorizontal) {           //Отрисовка и возможный переворто 1го корабля
        Graphics2D g2d = (Graphics2D) g;

        if (width <= 0) {                                                                                                  //Костыль для рисования в другую сторону
            width -= 2 * cellSize;
            x += cellSize;
        }
        if (height <= 0) {
            height -= 2 * cellSize;
            y += cellSize;
        }

        if (!isHorizontal) {
            double rotationRequired = Math.PI / 2;
            double locationX = img.getWidth(null) / 4.;
            double locationY = img.getHeight(null) / 4.;
            AffineTransform tx = AffineTransform.getRotateInstance(rotationRequired, locationX, locationY);
            AffineTransformOp op = new AffineTransformOp(tx, AffineTransformOp.TYPE_BILINEAR);
            g2d.drawImage(op.filter((BufferedImage) img, null), x, y, width, height, null);
        } else {
            g2d.drawImage(img, x, y, width, height, null);
        }
    }


    public void paintButtons(Graphics g) {
        if(battleCondition)
            return;
        int x1 = (int) (cellSize * 11 + cellSize * 1.66), y1 = (int) (cellSize * 11 + cellSize);
        int y2 = y1, x2 = (int) (cellSize * 11 + cellSize * 2.32);
        int size = (int) (cellSize * 0.5);
        try {
            Image acceptpImg  = ImageIO.read(getClass().getResource("/resources/acceptPlacingButton.png"));
            Image resetImg  = ImageIO.read(getClass().getResource("/resources/resetForPlacingButton.png"));
            g.drawImage(acceptpImg, x1, y1, size, size, null);
            g.drawImage(resetImg, x2, y2, size, size, null);
        } catch (Exception e) {
            e.printStackTrace();
        }
        if(isReady)
            paintLoadingMark(g);
    }

//    public void paintStartWindow(){
//
//    }

    public void paintStartWindow(Graphics g){
        Image backgroundImg = null;
        Image playGameImg = null;
        Image closeGameImg = null;
        try{
            backgroundImg = ImageIO.read(getClass().getResource("/resources/StartScreen.png"));
            playGameImg = ImageIO.read(getClass().getResource("/resources/Play.png"));
            closeGameImg = ImageIO.read(getClass().getResource("/resources/Close.png"));
        }catch (Exception e){e.printStackTrace();}
        g.drawImage(backgroundImg,0,0, getWidth(), getHeight(), null);
        int x = getWidth() / 2 - getWidth() / 4;
        int y1 = getHeight() / 2 - getHeight() / 5;
        int y2 = getHeight() / 2 - getHeight() / 5 + getHeight()/10;
        int width = (int)(getWidth() * 0.5);
        int height = (int) (getHeight() * 0.1);
        g.drawImage(playGameImg, x, y1, width, height, null);
        g.drawImage(closeGameImg, x, y2, width, height, null);
        paintLoadingMark(g);
    }
    public void paintLoadingMark(Graphics g){
        Image loadingImg = null;
        try {
            loadingImg = ImageIO.read(getClass().getResource("/resources/Loading.png"));
        }catch (Exception e){e.printStackTrace();}
        rotationOfLoaingMark += 0.034;
        double locationX = loadingImg.getWidth(null) / 4.;
        double locationY = loadingImg.getHeight(null) / 4.;
        AffineTransform tx = AffineTransform.getRotateInstance(rotationOfLoaingMark, locationX, locationY);
        AffineTransformOp op = new AffineTransformOp(tx, AffineTransformOp.TYPE_BILINEAR);
        Graphics2D g2d = (Graphics2D) g;
        g2d.drawImage(op.filter((BufferedImage) loadingImg, null), getWidth()-60, getHeight()-60, 50, 50, null);


    }

    public int[] getCoordsOfStartButtons(){
        int[] t = {0, 0, 0, 0, 0};
        t[0] = getWidth() / 2 - getWidth() / 4;
        t[1] = getHeight() / 2 - getHeight() / 5;
        t[2] = getHeight() / 2 - getHeight() / 5 + getHeight()/10;
        t[3] = (int)(getWidth() * 0.5);
        t[4] = (int) (getHeight() * 0.1);
        return t;
    }

    public void closeGame(){
        System.exit(0);
    }

    public void findOpponent(){
        if(!isStartPressed) {
            ThreadFactory.createThread(ThreadFactory.THREAD_FOR_SERVER, this);
            ThreadFactory.createThread(ThreadFactory.THREAD_FOR_SERVER_DETECTION, this);
            ThreadFactory.createThread(ThreadFactory.THREAD_FOR_BROADCAST, this);
            ThreadFactory.createThread(ThreadFactory.THREAD_FOR_LOADING, this);
        }
    }














    public boolean isBattleCondition() {return battleCondition;}
    public void setBattleCondition(boolean battleCondition) {this.battleCondition = battleCondition;}
    public void setIPDetected(boolean IPdetected){this.IPdetected = IPdetected;}
    public boolean isIPDetected(){return IPdetected;}
    public void setIPAdressOfOpponent(String IPAdressOfOpponent){this.IPAdressOfOpponent = IPAdressOfOpponent;}
    public void resetGameField(){gameField = new String[10][10];}
    public void resetNumberOfShips(){numberOfShips = new int[]{0, 4, 3, 2, 1};}
    public void resetShips(){Ships = new ArrayList<Ship>(10);}
    public int[] getNumberOfShips(){return numberOfShips;}
    public String getIPAdressOfOpponent(){return IPAdressOfOpponent;}
    public MainWindow1 getMv(){return mv;}
    public String getGameField() {
        String s = "";
        for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 10; j++) {
                if (j != 9)
                    s += gameField[i][j] + " ";
                else
                    s += gameField[i][j];
            }
            if (i != 9)
                s += "\n";
        }
        return s;
    }

    public boolean isSideIPdetected() {return sideIPdetected;}
    public void setSideIPdetected(boolean sideIPdetected) {this.sideIPdetected = sideIPdetected;}
    public String getSideIPAdress() {return sideIPAdress;}
    public boolean isLocalConnection() {return localConnection;}
    public void setSideIPAdress(String setIPAddress) {this.sideIPAdress = setIPAddress;}
    public void setLocalConnection(boolean localConnection) {this.localConnection = localConnection;}

    public void setGameStarted(boolean gameStarted) {
        this.gameStarted = gameStarted;
    }
    public boolean isGameStarted() {
        return gameStarted;
    }

    public boolean isStartPressed() {
        return isStartPressed;
    }

    public void setStartPressed(boolean startPressed) {
        isStartPressed = startPressed;
    }

    public boolean isReady() {
        return isReady;
    }

    public void setReady(boolean ready) {
        isReady = ready;
    }
    public void setRotationOfLoaingMark(int rotationOfLoaingMark){
        this.rotationOfLoaingMark = rotationOfLoaingMark;
    }

    public boolean isJustReady() {
        return isJustReady;
    }

    public void setJustReady(boolean justReady) {
        isJustReady = justReady;
    }

    public boolean isShootingJustStarted() {
        return isShootingJustStarted;
    }

    public void setShootingJustStarted(boolean shootingJustStarted) {
        isShootingJustStarted = shootingJustStarted;
    }

    public boolean isPlayersTurn() {
        return isPlayersTurn;
    }

    public void setPlayersTurn(boolean playersTurn) {
        isPlayersTurn = playersTurn;
    }

    public boolean isPropablePlayersTurn() {
        return isPropablePlayersTurn;
    }

    public void setPropablePlayersTurn(boolean propablePlayersTurn) {
        isPropablePlayersTurn = propablePlayersTurn;
    }

    public String[][] getOppponentsGameField() {
        return oppponentsGameField;
    }

    public void setOppponentsGameField(String [][] oppponentsGameField) {
        this.oppponentsGameField = oppponentsGameField;
    }

    public boolean isActionPerformed() {
        return isActionPerformed;
    }

    public void setActionPerformed(boolean actionPerformed) {
        isActionPerformed = actionPerformed;
    }
}