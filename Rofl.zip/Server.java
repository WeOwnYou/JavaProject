package com.company;

import java.io.*;
import java.net.*;

public class Server {

    private Game game;
    private int port;
    private int portForTest = 2001;
    private boolean running;
    private boolean isFirst = true;

    public Server(Game game) {
        port = 9000;
        running = true;
        this.game = game;
    }

    public void serverToDetect() {
        System.out.println("Started1");
        if(game.isIPDetected()) {
            System.out.println("ТипаНашел");
            return;
        }
        while (running){
            try {
                DatagramSocket ds = new DatagramSocket(9999);
                try {
                    byte[] buffer = new byte[1024];
                    DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
                    ds.receive(packet);

                    System.out.println(packet.getAddress().getHostAddress()+ "Это айпи1");                                               // + "  OPA \n " + new String(packet.getData(), 0, packet.getLength())

                    if(!game.isIPDetected()) {
                        game.setIPDetected(true);
                        game.setIPAdressOfOpponent(packet.getAddress().getHostAddress());
                    }else {
                        System.out.println(packet.getAddress().getHostAddress() + " &!");
                        if (!game.isSideIPdetected()) {
                            System.out.println(packet.getAddress().getHostAddress());
                            if (game.getIPAdressOfOpponent().equals(packet.getAddress().getHostAddress()))
                                continue;
                            System.out.println(packet.getAddress().getHostAddress() + " NAdo " + game.getIPAdressOfOpponent());
                            game.setSideIPdetected(true);
                            game.setSideIPAdress(packet.getAddress().getHostAddress());
                        } else {
                            running = false;
                            return;
                        }
                    }
                } catch (Exception e) {
                    System.out.println("Nado");
                }
            } catch (Exception e) {
//            System.out.println("Already exists");
            }
        }
        System.out.println("end server");
    }

    public  void mainServer(){
        System.out.println("StartedX");
        try {
            ServerSocket serverSocket = new ServerSocket(port);
            Socket socket = serverSocket.accept();
            game.setLocalConnection(true);
            InputStream sin = socket.getInputStream();
            DataInputStream in = new DataInputStream(sin);
            System.out.println("Got a client1 ");

            String line = null;
            while (running) {
                line = in.readUTF();
                if (isFirst) {
                    try {
                        line.split(".");
                        if (!game.isSideIPdetected()) {
                            game.setSideIPAdress(line);
                            game.setSideIPdetected(true);
                        }
                    } catch (Exception e) {
                        System.out.println("Ya retard");
                    }
                    isFirst = false;
                } else if (!game.isGameStarted()) {
                    game.setLocalConnection(true);
                    game.setGameStarted(true);
                    game.repaint();
                }else if (line.equals("Ready") && game.isReady()) {
                    game.setBattleCondition(true);
                    game.repaint();
                    game.getMv().addMouseListener(ListenerFactory.createMouseListener((ListenerFactory.MOUSE_LISTENER_WHILE_FIGHTNG), game));
                    game.setJustReady(false);                                                                                               //можно удалить*
                    game.setReady(false);
                    game.setShootingJustStarted(true);
                } else if (line.equals("MY_TURN") && !game.isPropablePlayersTurn() || line.equals("NOT_MY_TURN") && game.isPropablePlayersTurn()) {          //странно задает очередь
                    game.setShootingJustStarted(false);
                    game.setPropablePlayersTurn(false);
                    game.setPlayersTurn(true);
                } else if (line.equals("MY_TURN")) {
                    game.setShootingJustStarted(false);
                    game.setPropablePlayersTurn(false);
                    game.setPlayersTurn(false);
                } else {
//                System.out.println(line + "   !!!!!!");
                    String temp[] = line.split("\n");
                    String stringOpponentField[][] = new String[10][];
//                    System.out.println(line);
                    for (int i = 0; i < 10; i++)
                        try {
                            stringOpponentField[i] = temp[i].split(" ");
                        } catch (Exception e) {
                            System.out.println(temp[i] + "\n\n\n");
                        }
                    game.setOppponentsGameField(stringOpponentField);
                }
            }
        }catch (Exception e){e.printStackTrace();}
    }
}