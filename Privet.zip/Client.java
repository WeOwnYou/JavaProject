package com.company;

import java.net.*;
import java.io.*;

public class Client {
    public static void main(String[] ar) {
        int serverPort  = 667;
        String address = "192.168.0.104";
        boolean running = true;
//        try {
//            InetAddress ipAddress = InetAddress.getByName(address);
//            Socket s1 = new Socket(ipAddress, serverPort);
//        } catch (Exception e) {
//            serverPort = serverPort-1;
//            System.out.println("!");
//        }
        try {
            InetAddress ipAddress = InetAddress.getByName(address);
            System.out.println("Any of you heard of a socket with IP address " + address + " and port " + serverPort + "?");
            Socket socket = new Socket(ipAddress, serverPort);

            InputStream sin = socket.getInputStream();
            OutputStream sout = socket.getOutputStream();

            DataInputStream in = new DataInputStream(sin);
            DataOutputStream out = new DataOutputStream(sout);

            BufferedReader keyboard = new BufferedReader(new InputStreamReader(System.in));
            String line = null;
            while (running){
                line = keyboard.readLine();
                out.writeUTF(line);
                out.flush();
                line = in.readUTF();
                System.out.println("The server was very polite. It sent me this : " + line);
                System.out.println();
            }

        } catch (Exception e) {
//            e.printStackTrace();
            System.out.println("OHA");
        }
    }
}
