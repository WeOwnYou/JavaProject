package com.company;

import java.io.*;
import java.net.*;

public class Server {
    public static void main(String[] ar) {
        int port = 666;
        boolean running = true;
        try{
            ServerSocket ss = new ServerSocket(port);
            ServerSocket ss2 = new ServerSocket(667);
            System.out.println("Waiting for a client...");
            Socket socket = ss.accept();
            Socket socket2 = ss2.accept();
            System.out.println("Got a client :) ... Finally, someone saw me through all the cover!");

            InputStream sin = socket.getInputStream();
            OutputStream sout = socket.getOutputStream();

            DataInputStream in = new DataInputStream(sin);
            DataOutputStream out = new DataOutputStream(sout);



            InputStream sin2 = socket2.getInputStream();
            OutputStream sout2 = socket2.getOutputStream();

            DataInputStream in2 = new DataInputStream(sin2);
            DataOutputStream out2 = new DataOutputStream(sout2);
            String line = null;
            String line2 = null;
            while (running){
                line = in.readUTF();
                line2 = in2.readUTF();
                out.writeUTF(line2);
                out.flush();
                out2.writeUTF(line);
                out2.flush();
            }

        } catch (IOException e) {
            e.printStackTrace();
//            System.out.println("OPA");
        }
    }
}