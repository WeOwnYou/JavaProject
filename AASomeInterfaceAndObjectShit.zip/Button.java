package com.company;

import java.awt.*;

public class Button {

    private int x0, y0, width, height, typeOfScreen, typeOfButton;
    private Image buttonImg;
    public static final int START_SCREEN_BUTTON = 0, PLACE_SCREEN_BUTTON = 1, FIGHT_SCREEN_BUTTON = 2;
    public static final int PLAY_GAME_BUTTON = 3, EXIT_GAME_BUTTON = 4, ACCEPT_PLACING_BUTTON = 5, RESET_PLACING_BUTTON = 6;

    public Button(int x0, int y0, int width, int height, int typeOfScreen, int typeOfButton, Image img){
        this.x0 = x0;
        this.y0 = y0;
        this.width = width;
        this.height = height;
        this.buttonImg = img;
        this.typeOfButton = typeOfButton;
        this.typeOfScreen = typeOfScreen;
    }


    public Image getButtonImg() {
        return buttonImg;
    }

    public int getX0() {
        return x0;
    }

    public int getY0() {
        return y0;
    }

    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }

    public int getTypeOfScreen() {
        return typeOfScreen;
    }

    public int getTypeOfButton() {
        return typeOfButton;
    }
}
