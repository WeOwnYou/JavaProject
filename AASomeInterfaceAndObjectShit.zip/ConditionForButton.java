package com.company;

public interface ConditionForButton {
    public  boolean conditionForNotUsing();
}
