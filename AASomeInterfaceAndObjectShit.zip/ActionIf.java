package com.company;

public interface ActionIf {
    public void ActionIfButtonIsPressed();
}
