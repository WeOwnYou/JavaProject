package com.company;

public class ConditionForButtons implements ConditionForButton {

    private int type;
    private Game game;

    public ConditionForButtons(int type, Game game) {
        this.type = type;
        this.game = game;
    }

    public boolean conditionForNotUsing() {
        switch (type) {
            case Button.START_SCREEN_BUTTON:
                return game.isGameStarted();
            case Button.PLACE_SCREEN_BUTTON:
                return !(game.isBattleCondition() || game.isGameStarted()) && !game.isReady();
            case Button.FIGHT_SCREEN_BUTTON:
                return true;
        }
        return true;
    }
}
