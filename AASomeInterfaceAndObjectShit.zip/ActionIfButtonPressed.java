package com.company;

public class ActionIfButtonPressed implements ActionIf {

    private int type;
    private Game game;

    public ActionIfButtonPressed(int type, Game game) {
        this.type = type;
        this.game = game;
    }

    public void ActionIfButtonIsPressed() {
        switch (type) {
            case Button.PLAY_GAME_BUTTON:                                                                               //action
                game.findOpponent();
                game.setPlayPressed(true);                                                                              //action
                return;
            case Button.EXIT_GAME_BUTTON:
                game.closeGame();
                return;
            case Button.ACCEPT_PLACING_BUTTON:
                boolean isAllShipsPlaced = true;
                int t[] = game.getNumberOfShips();
                for (int i = 0; i < 5; i++)
                    if (t[i] != 0) {
                        isAllShipsPlaced = false;
                        break;
                    }
                if (isAllShipsPlaced && !game.isReady()) {
                    game.setReady(true);
                    System.out.println("???");
                    game.setIsStartOfGame(true);
                    ThreadFactory.createThread(ThreadFactory.THREAD_FOR_LOADING, game);
                }
                return;
            case Button.RESET_PLACING_BUTTON:
                game.resetGameField();
                game.resetNumberOfShips();
                game.resetShips();
                game.repaint();
                return;
        }
    }
}
