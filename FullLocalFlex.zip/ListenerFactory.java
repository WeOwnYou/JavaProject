package com.company;


import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;

public class ListenerFactory {

    public static final int MOUSE_LISTENER_WHILE_PLACING = 1;
    public static final int MOUSE_LISTENER_WHILE_FIGHTNG = 2;
    public static final int MOUSE_LISTENER_FOR_BUTTONS = 3;
    private static ArrayList <Pair> mouseFactory;

    public ListenerFactory(){
        mouseFactory = new ArrayList<Pair>();
    }

    public static class  MLWPlacing implements MouseListener {

        private int x0, y0, x1, y1;
        private boolean isHorizontal;
        private Game game;

        private MLWPlacing(Game game) {
            this.game = game;
        }

        @Override
        public void mouseClicked(MouseEvent mouseEvent) {
        }

        @Override
        public void mousePressed(MouseEvent mouseEvent) {
            if(game.isBattleCondition())
                return;
            x0 = mouseEvent.getX() - 10;                                                                                   //эксепты для неправльного ввода
            y0 = mouseEvent.getY() - 30;
        }

        @Override
        public void mouseReleased(MouseEvent mouseEvent) {
            if(game.isBattleCondition())
                return;
            x1 = mouseEvent.getX() - 10;
            y1 = mouseEvent.getY() - 30;

            int cellSize = this.game.countCellSize();
            int x0 = (int) ((float) this.x0 / (float) cellSize) - 1;
            int y0 = (int) ((float) this.y0 / (float) cellSize) - 1;
            int x1 = (int) ((float) this.x1 / (float) cellSize) - 1;
            int y1 = (int) ((float) this.y1 / (float) cellSize) - 1;
            try {
                if (x1 - x0 == 0) {
                    isHorizontal = false;
                    this.game.createShip(x0, y0, x1, y1, isHorizontal);
                } else {
                    if (y1 - y0 == 0) {
                        isHorizontal = true;
                        this.game.createShip(x0, y0, x1, y1, isHorizontal);
                    }
                }
            } catch (Exception e) {
//                System.out.println(x0 + " " + y0 + " " + x1 + " " + y1);
            }
        }

        @Override
        public void mouseEntered(MouseEvent mouseEvent) {

        }

        @Override
        public void mouseExited(MouseEvent mouseEvent) {

        }
    }

    public static class MLForButtons implements MouseListener{

        private Game game;

        private MLForButtons(Game game) {
            this.game = game;
        }

        @Override
        public void mouseClicked(MouseEvent mouseEvent) {
            if(game.isBattleCondition())
                return;
            System.out.println(game.isBattleCondition() + " !11");
            int coords [] = game.createButtonsForPlacingResetAndAccept();
            int x =  mouseEvent.getX()-10;
            int y = mouseEvent.getY()-30;
            if ((coords[2] <= x && coords[2]+coords[4] >= x) && (coords[3] <= y && coords[3]+coords[4] >= y)){
                game.resetGameField();
                game.resetNumberOfShips();
                game.resetShips();
                game.repaint();
            }else {
                boolean isAllShipsPlaced = true;
                int t[] = game.getNumberOfShips();
                for(int i = 0;i < 5;i++)
                    if (t[i] !=0 ) {
                        isAllShipsPlaced = false;
                        break;
                    }
                    System.out.println(((coords[0] <= x && coords[0] + coords[4] >= x) && (coords[1] <= y && coords[1] + coords[4] >= y)) + "? " + isAllShipsPlaced);
                if ((coords[0] <= x && coords[0] + coords[4] >= x) && (coords[1] <= y && coords[1] + coords[4] >= y) && isAllShipsPlaced) {
                    game.setBattleCondition(true);
                    game.repaint();
                    game.getMv().addMouseListener(ListenerFactory.createMouseListener((ListenerFactory.MOUSE_LISTENER_WHILE_FIGHTNG), game));
                    System.out.println("SOZDAL");
                }
            }



        }

        @Override
        public void mousePressed(MouseEvent mouseEvent) {

        }

        @Override
        public void mouseReleased(MouseEvent mouseEvent) {

        }

        @Override
        public void mouseEntered(MouseEvent mouseEvent) {

        }

        @Override
        public void mouseExited(MouseEvent mouseEvent) {

        }
    }

    public static class MLWFighting implements MouseListener{

        private Game game;

        public MLWFighting(Game game){this.game = game;}


        @Override
        public void mouseClicked(MouseEvent e) {

        }

        @Override
        public void mousePressed(MouseEvent e) {
        }

        @Override
        public void mouseReleased(MouseEvent e) {
            if(!game.isBattleCondition())
                return;
            int cellSize = this.game.countCellSize();
            int x0 = (int) ( (e.getX()-10)/ (float) cellSize) - 1;
            int y0 = (int) ((e.getY()-30)/ (float) cellSize) - 1;
            if(!(x0 <= 9 && x0 >= 0 && y0 <= 9 && y0 >=0))
                return;
            game.shooting(x0, y0);
        }

        @Override
        public void mouseEntered(MouseEvent e) {

        }

        @Override
        public void mouseExited(MouseEvent e) {
        }
    }
    public static MouseListener createMouseListener(int type, Game game) {
        MouseListener result = null;
        System.out.println(type + " " +MOUSE_LISTENER_WHILE_FIGHTNG);

        try {
            switch (type) {
                case MOUSE_LISTENER_FOR_BUTTONS:
                    result = new MLForButtons(game);
                    Pair<Integer, MouseListener> temp = new Pair<>(MOUSE_LISTENER_FOR_BUTTONS, result);
                    mouseFactory.add(temp);
                    return result;
                case MOUSE_LISTENER_WHILE_PLACING:
                    result = new MLWPlacing(game);
                    Pair<Integer, MouseListener> temp1 = new Pair<>(MOUSE_LISTENER_WHILE_PLACING, result);
                    mouseFactory.add(temp1);
                    return result;
                case MOUSE_LISTENER_WHILE_FIGHTNG:
                    System.out.println("CREATED");
                    result = new MLWFighting(game);
                    return result;
//                    Pair<Integer, MouseListener> temp2 = new Pair<>(MOUSE_LISTENER_WHILE_FIGHTNG, result);
//                    mouseFactory.add(temp2);
//                    System.out.println("CREATED");

            }
        }catch (NullPointerException e){
//            System.out.println("X,m");
            e.fillInStackTrace();
        }
        return result;
    }
    public static void deleteMouseListener(int type, Game game) {
        if(!game.isBattleCondition())
            return;
        try {
//            System.out.println("!!");
            switch (type) {
                case MOUSE_LISTENER_FOR_BUTTONS:
                    for (int i = 0; i < mouseFactory.size(); i++)
                        if ((int) mouseFactory.get(i).getFirst() == MOUSE_LISTENER_FOR_BUTTONS) {
                            game.getMv().removeMouseListener((MouseListener) mouseFactory.get(i).getSecond());
                            mouseFactory.remove(i);
                            break;
                        }
                case MOUSE_LISTENER_WHILE_PLACING:
                    for (int i = 0; i < mouseFactory.size(); i++)
                        if ((int) mouseFactory.get(i).getFirst() == MOUSE_LISTENER_WHILE_PLACING) {
                            game.getMv().removeMouseListener((MouseListener) mouseFactory.get(i).getSecond());
                            mouseFactory.remove(i);
                            break;
                        }
            }
        }catch (NullPointerException e){System.out.println("E");}
    }
}
