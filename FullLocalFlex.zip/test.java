//package com.company;
//
//import java.io.*;
//import java.net.ServerSocket;
//import java.net.Socket;
//
//public class testpackage com.company;
//
//        import java.io.*;
//        import java.net.*;
//
//public class Server {
//    public static void main(String[] ar) {
//        int port = 666;
//        boolean running = true;
//        try{
//            ServerSocket ss = new ServerSocket(port);
//            System.out.println("Waiting for a client...");
//            Socket socket = ss.accept();
//            System.out.println("Got a client :) ... Finally, someone saw me through all the cover!");
//
//            InputStream sin = socket.getInputStream();
//            OutputStream sout = socket.getOutputStream();
//
//            DataInputStream in = new DataInputStream(sin);
//            DataOutputStream out = new DataOutputStream(sout);
//            String line = null;
//            while (running){
//                line = in.readUTF();
//                out.writeUTF(line);
//                out.flush();
//            }
//
//        } catch (IOException e) {
////            e.printStackTrace();
//            System.out.println("OPA");
//        }
//    }
//}
// {
//}
