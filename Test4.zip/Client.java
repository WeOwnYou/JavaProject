package com.company;

import java.net.*;
import java.io.*;
import java.util.*;

public class Client extends Thread {

    private String s;
    private String addressOfNetwork;
    private String address;
    private boolean running;
    private Game game;
    private int port = 9000;
    private boolean isMyAddressWroteToOppomemt = false;
    private boolean fl = true;

    public Client(Game game) {
        this.game = game;
        this.s = "1";
        this.running = true;
        this.addressOfNetwork = "10.1.1.255";
        try {
            addressOfNetwork();
        } catch (Exception e) {
            System.out.println("Так не должно быть");
        }
    }

    public void addressOfNetwork() throws Exception {
        String adr = InetAddress.getByName(addressOfNetwork).getLocalHost().getHostAddress();
        StringBuilder sb = new StringBuilder();
        Scanner scaner = new Scanner(adr);
        scaner.useDelimiter("\\.");
        sb.append(scaner.next() + ".");
        sb.append(scaner.next() + ".");
        sb.append(scaner.next() + ".");
        sb.append(255);
        this.addressOfNetwork = sb.toString();
    }

    public void sendPacketToDetect() throws Exception {
        if (game.isIPDetected() && game.isSideIPdetected())
            return;

        MulticastSocket ms = new MulticastSocket(1024);

        byte[] buffer;
        buffer = s.getBytes();

        InetAddress ipAddress = InetAddress.getByName(addressOfNetwork);
        DatagramPacket packet = new DatagramPacket(buffer, buffer.length, ipAddress, 9999);
        while (running) {
            ms.send(packet);
            Thread.sleep(5000);
            if (game.isIPDetected() && game.isSideIPdetected()) {
                mainClient();
            }
            if (game.isLocalConnection()) {
                return;
            }
        }
    }

    public void mainClient() {
        System.out.println("Connection is started to be");
        address = game.getSideIPAdress();
        try {
            InetAddress ipAddress = InetAddress.getByName(address);
            System.out.println(address + "  Это я вроде как отсылаю другому челику на дпугой ип");
            Socket socket = new Socket(ipAddress, port);
            OutputStream os = socket.getOutputStream();
            DataOutputStream out = new DataOutputStream(os);

            while (running) {

                if (!isMyAddressWroteToOppomemt) {
                    isMyAddressWroteToOppomemt = true;
                    out.writeUTF(game.getIPAdressOfOpponent());
                }//ok
                else if (game.isReady()) {                                                                                //если начало игры сделать нулевой ротатион
                    if (game.isJustReady()) {
                        game.setRotationOfLoaingMark(0);
                        game.setJustReady(false);
                    }
                    out.writeUTF("Ready");
                } else if (Server.isTurnSeted && game.isActionPerformed()) {
                        out.writeUTF(game.getGameField());
                        Thread.sleep(950);
                    }
                Thread.sleep(50);
//                System.out.println("VYVOD");
            }

        } catch (Exception e) {
            System.out.println("ended");
            e.printStackTrace();
        }
    }
}