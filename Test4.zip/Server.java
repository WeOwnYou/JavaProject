package com.company;

import java.net.*;
import java.io.*;
import java.util.*;

public class Server {

    private Game game;
    private int port;
    private int portForTest = 2001;
    private boolean running;
    private boolean isItIp = true;
    public static boolean isTurnSeted = false;

    public Server(Game game) {
        port = 9000;
        running = true;
        this.game = game;
    }

    public void serverToDetect() {
        System.out.println("Started1");
        if (game.isIPDetected()) {
            System.out.println("ТипаНашел");
            return;
        }
        while (running) {
            try {
                DatagramSocket ds = new DatagramSocket(9999);
                try {
                    byte[] buffer = new byte[1024];
                    DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
                    ds.receive(packet);

                    System.out.println(packet.getAddress().getHostAddress() + "Это айпи1");                                               // + "  OPA \n " + new String(packet.getData(), 0, packet.getLength())

                    if (!game.isIPDetected()) {
                        game.setIPDetected(true);
                        game.setIPAdressOfOpponent(packet.getAddress().getHostAddress());
                    } else {
                        System.out.println(packet.getAddress().getHostAddress() + " &!");
                        if (!game.isSideIPdetected()) {
                            System.out.println(packet.getAddress().getHostAddress());
                            if (game.getIPAdressOfOpponent().equals(packet.getAddress().getHostAddress()))
                                continue;
                            System.out.println(packet.getAddress().getHostAddress() + " NAdo " + game.getIPAdressOfOpponent());
                            game.setSideIPdetected(true);
                            game.setSideIPAdress(packet.getAddress().getHostAddress());
                        } else {
                            running = false;
                            return;
                        }
                    }
                } catch (Exception e) {
                    ;
                }
            } catch (Exception e) {
//            System.out.println("Already exists");
            }
        }
        System.out.println("end server");
    }

    public void mainServer() {
        try {

            ServerSocket serverSocket = new ServerSocket(port);
            Socket socket = serverSocket.accept();
            game.setLocalConnection(true);
            InputStream sin = socket.getInputStream();
            DataInputStream in = new DataInputStream(sin);
            String line = null;
            //ok
            while (running) {
                System.out.println(line + " " + game.isReady() + " ??");
                line = in.readUTF();
                if (isItIp) {
                    line.split(".");
                    if (!game.isSideIPdetected()) {
                        game.setSideIPAdress(line);
                        game.setSideIPdetected(true);
                    }
                    isItIp = false;

                    game.setLocalConnection(true);
                    game.setGameStarted(true);
                    game.repaint();

                } else if (line.equals("Ready") && game.isReady() && !isTurnSeted) {

                    if (!isTurnSeted) {//&& Integer.parseInt(game.getSideIPAdress().split("\\.")[3]) > Integer.parseInt(game.getIPAdressOfOpponent().split("\\.")[3])) {
                        System.out.println("Ne");
                        game.setPlayersTurn(false);
                        isTurnSeted = false;
//                    } else if (!isTurnSeted) {
//                        System.out.println("Ne");
//                        game.setPlayersTurn(false);
//                        isTurnSeted = false;
//                    }

                        ListenerFactory.deleteMouseListener(ListenerFactory.MOUSE_LISTENER_FOR_BUTTONS, game);
                        ListenerFactory.deleteMouseListener(ListenerFactory.MOUSE_LISTENER_WHILE_PLACING, game);
                        game.getMv().addMouseListener(ListenerFactory.createMouseListener((ListenerFactory.MOUSE_LISTENER_WHILE_FIGHTNG), game));
                        game.setBattleCondition(true);
                        game.setJustReady(true);
                        game.setShootingJustStarted(true);
                        System.out.println("FIGHT");
                        //ok
                    } else if (isTurnSeted) {
                        try {
//                System.out.println(line + "   !!!!!!");
                            String temp[] = line.split("\n");
                            String stringOpponentField[][] = new String[10][];
//                    System.out.println(line);
                            for (int i = 0; i < 10; i++)
//                                try {
                                stringOpponentField[i] = temp[i].split(" ");
//                                } catch (Exception e) {
//                                    System.out.println(temp[i] + "\n\n\n");
//                                }
                            game.setOppponentsGameField(stringOpponentField);
                            game.setPlayersTurn(true);
                        } catch (Exception e) {
                            System.out.println(line);
                        }
                    }
                }
            }
        }catch (Exception e){e.printStackTrace();}
    }
}