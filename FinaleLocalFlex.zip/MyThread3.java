package com.company;

public class MyThread3 extends Thread {

    private Game game;

    public MyThread3(Game game) {
        this.game = game;
    }

    public void run() {
        Server server = new Server(game);
        server.mainServer();
    }
}